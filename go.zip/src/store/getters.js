// export const singer = state => state.singer

export const calendarList = state => state.calendarList
export const oid = state => state.oid
export const nickName = state => state.nickName
export const avatarUrl = state => state.avatarUrl
export const canIUse = state => state.canIUse
export const visible = state => state.visible
export const authPhone = state => state.authPhone
