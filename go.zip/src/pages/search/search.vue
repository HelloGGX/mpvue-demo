<!--  -->
<template>
  <div>搜索</div>
</template>

<script type='text/ecmascript-6'>
export default {
  data () {
    return {
    }
  }
}
</script>
<style lang='less' scoped>
</style>