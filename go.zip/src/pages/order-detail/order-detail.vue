<!-- 订单详情页面 -->
<template>
  <div>订单详情</div>
</template>

<script type='text/ecmascript-6'>
export default {
  data () {
    return {
    }
  },

  components: {}
}
</script>
<style lang='less' scoped>
</style>
